:mod:`corpora.hashdictionary` -- Construct word<->id mappings
=============================================================

.. automodule:: gensim.corpora.hashdictionary
    :synopsis: Construct word<->id mappings on the fly (the "hashing trick")
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
