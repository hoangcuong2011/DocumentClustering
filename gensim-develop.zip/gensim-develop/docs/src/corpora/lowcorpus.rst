:mod:`corpora.lowcorpus` -- Corpus in List-of-Words format
===========================================================

.. automodule:: gensim.corpora.lowcorpus
    :synopsis: Corpus in List-of-Words format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
