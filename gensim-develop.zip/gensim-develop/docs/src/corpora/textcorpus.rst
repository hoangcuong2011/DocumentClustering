:mod:`corpora.textcorpus` -- Building corpora with dictionaries
=================================================================

.. automodule:: gensim.corpora.textcorpus
    :synopsis: Building corpora with dictionaries
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
