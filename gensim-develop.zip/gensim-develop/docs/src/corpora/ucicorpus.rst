:mod:`corpora.ucicorpus` -- Corpus in UCI bag-of-words format
==============================================================================================================

.. automodule:: gensim.corpora.ucicorpus
    :synopsis: Corpus in University of California, Irvine (UCI) bag-of-words format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
