:mod:`models.lda_worker` -- Worker for distributed LDA
======================================================

.. automodule:: gensim.models.lda_worker
    :synopsis: Worker for distributed LDA
    :members:
    :inherited-members:

