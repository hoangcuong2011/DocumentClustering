:mod:`models.wrappers.dtmmodel` -- Dynamic Topic Models (DTM) and Dynamic Influence Models (DIM)
================================================================================================

.. automodule:: gensim.models.wrappers.dtmmodel
    :synopsis: Dynamic Topic Models
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
