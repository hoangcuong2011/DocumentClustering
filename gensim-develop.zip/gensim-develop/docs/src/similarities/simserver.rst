:mod:`simserver` -- Document similarity server
======================================================

.. automodule:: simserver.simserver
    :synopsis: Document similarity server
    :members:
    :inherited-members:

