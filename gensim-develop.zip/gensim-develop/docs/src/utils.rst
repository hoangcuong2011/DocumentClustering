:mod:`utils` -- Various utility functions
==========================================

.. automodule:: gensim.utils
    :synopsis: Various utility functions
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
